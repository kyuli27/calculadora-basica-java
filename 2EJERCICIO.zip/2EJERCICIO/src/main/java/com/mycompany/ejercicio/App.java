/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio;

import java.util.Scanner;

/**
 *
 * @author 50497
 */
public class App {

    public static void main(String[] args) {
     
    Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingresa el primer número entero: ");
        int num1 = scanner.nextInt();
        
        System.out.print("Ingresa el segundo número entero: ");
        int num2 = scanner.nextInt();
        
        int suma = num1 + num2;
        int resta = num1 - num2;
        int multiplicacion = num1 * num2;
        
        if (num2 != 0) {
            int division = num1 / num2;
            int modulo = num1 % num2;
            
            System.out.println("Suma: " + suma);
            System.out.println("Resta: " + resta);
            System.out.println("Multiplicación: " + multiplicacion);
            System.out.println("División: " + division);
            System.out.println("Módulo: " + modulo);
        } else {
            System.out.println("No se puede realizar la división y el módulo porque el segundo número es 0.");
        }
    }
}
